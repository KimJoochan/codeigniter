<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Db_table_optimize  {
    protected $ci;
    public $super_hp;
    function __construct(){
        $this->ci =& get_instance();
        $this->ci->load->model('Query_model');
        $this->ci->load->library('global_lib');
        $this->ci->load->library('common_lib');
        $this->ci->load->library('partner_lib');
        $this->ci->load->helper('url');
        $this->ci->load->helper('global_helper');
    }
    function common(){
        // 실행일 비교
        $default=$this->ci->load->get_var('default');
        $OM_SERVER_TIME=time();
        $OM_TIME_YMDHIS=date('Y-m-d H:i:s',$OM_SERVER_TIME);
        $OM_TIME_YMD=substr($OM_TIME_YMDHIS, 0, 10);

        if(isset($default['de_optimize_date']) && $default['de_optimize_date'] >= $OM_TIME_YMD)
            return;

        // 설정일이 지난 장바구니 상품 삭제
        if($default['de_cart_keep_term'] > 0) {
            $tmp_before_date = date("Y-m-d", $OM_SERVER_TIME - ($default['de_cart_keep_term'] * 86400));
            $sql = " delete from shop_cart where left(ct_time,10) < '$tmp_before_date' and ct_select='0' and od_id='' ";
            $this->ci->Query_model->returnNull($sql);
        }

        // 설정일이 지난 찜상품 삭제
        if($default['de_wish_keep_term'] > 0) {
            $tmp_before_date = date("Y-m-d", $OM_SERVER_TIME - ($default['de_wish_keep_term'] * 86400));
            $sql = " delete from shop_wish where left(wi_time,10) < '$tmp_before_date' ";
            $this->ci->Query_model->returnNull($sql);
        }

        // 설정일이 지난 배송완료상품 구매확정
        if($default['de_final_keep_term'] > 0) {
            $tmp_before_date = date("Y-m-d", $OM_SERVER_TIME - ($default['de_final_keep_term'] * 86400));
            $sql = " update shop_order
                        set user_ok = '1'
                        , user_date = '".$OM_TIME_YMDHIS."'
                    where left(invoice_date,10) < '$tmp_before_date'
                        and user_ok = '0'
                        and dan = '5' ";
            $this->ci->Query_model->returnNull($sql);
        }

        // 설정일이 지난 미입금된 주문내역 자동취소
        if($default['de_misu_keep_term'] > 0) {
            $tmp_before_date = date("Y-m-d", $OM_SERVER_TIME - ($default['de_misu_keep_term'] * 86400));
            $sql = " select *
                    from shop_order
                    where left(od_time,10) < '$tmp_before_date'
                        and dan = '1'
                    order by index_no ";
            #$res = sql_query($sql);
            $res=$this->ci->Query_model->returnArr($sql);
            foreach($res as $key => $row){
                $this->ci->funcomplex_lib->change_order_status_6($row['od_no']);

                // 메모남김
                $sql = " update shop_order
                            set shop_memo = CONCAT(shop_memo,\"\\n미입금 자동 주문취소 - ".$OM_TIME_YMDHIS." (취소이유 : {$default['de_misu_keep_term']}일경과)\")
                        where od_no = '{$row['od_no']}' ";
                $this->ci->Query_model->returnNull($sql);
            }
            /*
            while($row=sql_fetch_array($res)) {
                change_order_status_6($row['od_no']);

                // 메모남김
                $sql = " update shop_order
                            set shop_memo = CONCAT(shop_memo,\"\\n미입금 자동 주문취소 - ".$OM_TIME_YMDHIS." (취소이유 : {$default['de_misu_keep_term']}일경과)\")
                        where od_no = '{$row['od_no']}' ";
                sql_query($sql);
            }
            */
        }

        // 실행일 기록
        if(isset($default['de_optimize_date'])) {
            // sql_query(" update shop_default set de_optimize_date = '".$OM_TIME_YMD."' ");
            $sql=" update shop_default set de_optimize_date = ?";
            $data=array($OM_TIME_YMD);
            $this->ci->Query_model->returnNull($sql,$data);
        }

        unset($tmp_before_date);
    }   
}