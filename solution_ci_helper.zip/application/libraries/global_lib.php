<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class global_lib {
    protected $ci;
    protected $OM_TIME_YMDHIS;
    protected $OM_TIME_HIS;
    public function __construct(){
        $this->ci =& get_instance();
        $this->ci->load->model('Query_model');
        $this->OM_TIME_YMDHIS=date("Y-m-d H:i:s", time());
        $this->OM_TIME_HIS==date("H:i:s", time());
        // Do something with $params
    }
    // 상품명과 건수를 반환
    function get_full_name($cart_id){
        // 상품명만들기
        #$row = sql_fetch(" select a.gs_id, b.gname from shop_cart a, shop_goods b where a.gs_id = b.index_no and a.od_id = '$cart_id' order by a.index_no limit 1 ");
        $sql="select a.gs_id, b.gname from shop_cart a, shop_goods b where a.gs_id = b.index_no and a.od_id = ? order by a.index_no limit 1";
        $data=array($cart_id);
        $row=$this->ci->Query_model->returnOneArr($sql,$data);
        // 상품명에 "(쌍따옴표)가 들어가면 오류 발생함
        $goods['gs_id'] = $row['gs_id'];
        $goods['full_name']= $goods['name'] = addslashes($row['gname']);
        // 특수문자제거
        $goods['full_name'] = preg_replace ("/[ #\&\+\-%@=\/\\\:;,\.'\"\^`~\_|\!\?\*$#<>()\[\]\{\}]/i", "",  $goods['full_name']);

        // 상품건수
        #$row = sql_fetch(" select count(*) as cnt from shop_cart where od_id = '$cart_id' ");
        $sql2="select count(*) as cnt from shop_cart where od_id = ?";
        $data2=array($cart_id);
        $row=$this->ci->Query_model->returnOneArr($sql2,$data2);
        $cnt = $row['cnt'] - 1;
        if($cnt)
            $goods['full_name'] .= ' 외 '.$cnt.'건';
        $goods['count'] = $row['cnt'];
        return $goods;
    }
    // 복합과세
    function comm_tax_flag($od_id){
        $comm_tax_mny	= 0; // 과세금액
        $comm_vat_mny	= 0; // 부가세
        $comm_free_mny	= 0; // 면세금액
        $tot_tax_mny	= 0;
        $tot_baesong	= 0;

        #$sql = " select * from shop_order where od_id = '$od_id' order by index_no ";
        $sql=" select * from shop_order where od_id =? order by index_no ";
        $data=array($od_id);
        $result=$this->ci->Query_model->returnArr($sql,$data);
        foreach($result as $key => $row){
            if($row['gs_notax']) // 과세
                $tot_tax_mny += ($row['use_price'] - $row['baesong_price']);
            else // 면세
                $comm_free_mny += ($row['use_price'] - $row['baesong_price']);

            $tot_baesong += $row['baesong_price'];
        }
        $comm_tax_mny = round(($tot_tax_mny + $tot_baesong) / 1.1);
        $comm_vat_mny = ($tot_tax_mny + $tot_baesong) - $comm_tax_mny;

        $info = array();
        $info['comm_tax_mny']  = $comm_tax_mny;
        $info['comm_vat_mny']  = $comm_vat_mny;
        $info['comm_free_mny'] = $comm_free_mny;

        return $info;
    }
    /*******************************************************************************
    유일한 키를 얻는다.

    결과 :

        년월일시분초00 ~ 년월일시분초99
        년(4) 월(2) 일(2) 시(2) 분(2) 초(2) 100분의1초(2)
        총 16자리이며 년도는 2자리로 끊어서 사용해도 됩니다.
        예) 2008062611570199 또는 08062611570199 (2100년까지만 유일키)

    사용하는 곳 :
    1. 주문번호 생성시에 사용한다.
    2. 기타 유일키가 필요한 곳에서 사용한다.
    *******************************************************************************/
    function get_uniqid(){
        #sql_query(" LOCK TABLE shop_uniqid WRITE ");
        $sql="LOCK TABLE shop_uniqid WRITE";
        $this->ci->Query_model->returnNull($sql);
        while (1) {
            // 년월일시분초에 100분의 1초 두자리를 추가함 (1/100 초 앞에 자리가 모자르면 0으로 채움)
            $key = date('ymdHis', time()) . str_pad((int)(microtime()*100), 2, "0", STR_PAD_LEFT);

            #$result = sql_query(" insert into shop_uniqid set uq_id = '$key', uq_ip = '{$_SERVER['REMOTE_ADDR']}' ", false);
            $sql2="insert into shop_uniquid set up_id = ?, up_ip=?";
            $data2=array($key,$_SERVER['REMOTE_ADDR']);
            $result=$this->ci->Query_model->returnQueryObj($sql2,$data2);
            if($result) break; // 쿼리가 정상이면 빠진다.

            // insert 하지 못했으면 일정시간 쉰다음 다시 유일키를 만든다.
            usleep(10000); // 100분의 1초를 쉰다
        }
        #sql_query(" UNLOCK TABLES ");
        $sql="UNLOCK TABLES";
        $this->ci->Query_model->returnNull($sql);
        return $key;
    }
    // 장바구니 유일키검사
    function cart_uniqid(){
        while(1) {
            srand((double)microtime()*1000000);
            $key = rand(1000000000,9999999999);
            #$row1 = sql_fetch(" select count(*) as cnt from shop_cart where od_no = '$key' ");
            $sql1="select count(*) as cnt from shop_cart where od_no =?";
            $data=array($key);
            $row1=$this->ci->Query_model->returnOneArr($sql1,$data);
            #$row2 = sql_fetch(" select count(*) as cnt from shop_order where od_no = '$key' ");
            $sql2="select count(*) as cnt from shop_order where od_no = ?";
            $data2=array($key);
            $row2=$this->ci->Query_model->returnOneArr($sql2,$data2);
            if(!$row1['cnt'] && !$row2['cnt']) break; // 없다면 빠진다.

            // count 하지 못했으면 일정시간 쉰다음 다시 유일키를 검사한다.
            usleep(10000); // 100분의 1초를 쉰다
        }
        return $key;
    }
    // 상품의 재고 (창고재고수량)
    function get_it_stock_qty($gs_id){
        #$sql = " select stock_qty,stock_mod from shop_goods where index_no = '$gs_id' ";
        #$row = sql_fetch($sql);
        $sql = " select stock_qty,stock_mod from shop_goods where index_no = ? ";
        $data=array($gs_id);
        $row=$this->ci->Query_model->returnOneArr($sql,$data);
        $jaego = (int)($row->stock_qty);
        if(!($row['stock_mod'])) {
            $jaego = 999999999;
        }
        return $jaego;
    }
    // 쿠폰 : 사용 가능한 쿠폰
    function get_cp_precompose($mb_id){
        $query = array();

        // 쿠폰유효 기간 (날짜)
        $fr_date = "(cp_inv_sdate = '9999999999' or cp_inv_sdate <= curdate())";
        $to_date = "(cp_inv_edate = '9999999999' or cp_inv_edate >= curdate())";

        // 쿠폰유효 기간 (시간대)
        $fr_hour = "(cp_inv_shour1 = '99' or cp_inv_shour1 <= date_format(now(),'%H'))";
        $to_hour = "(cp_inv_shour2 = '99' or cp_inv_shour2 > date_format(now(),'%H'))";

        $query[0]  = " from shop_coupon_log ";
        $query[1]  = " where mb_id='$mb_id' and mb_use='0' ";
        $query[1] .= " and ((cp_inv_type='0' and ($fr_date and $to_date) and ($fr_hour and $to_hour)) ";
        $query[1] .= " or (cp_inv_type='1' and date_add(`cp_wdate`, interval `cp_inv_day` day) > now())) ";
        $query[2]  = " order by lo_id ";

        #$sql = " select count(*) as cnt {$query[0]} {$query[1]} ";
        $sql = " select count(*) as cnt ? ?";
        $data=array($query[0],$query[1]);
        #$row = sql_fetch($sql);
        $row=$this->ci->Query_model->returnOneArr($sql,$data);
        $query[3] = (int)$row['cnt'];

        return $query;
    }
    #문자설정 정보
    function get_sms($mb_id){
        #return sql_fetch("select * from shop_sms where mb_id='$mb_id' ");
        $sql="select * from shop_sms where mb_id=?";
        $data=array($mb_id);
        return $this->ci->Query_model->returnOneArr($sql,$data);
    }
    // 회원의 정보를 추출 ($mb_no는 회원의 주키값)
    function get_member_no($mb_no, $fileds='*'){
        #return sql_fetch("select $fileds from shop_member where index_no='$mb_no' ");
        if($fileds=="*"){
            $sql="select * from shop_member where index_no=?";
            $data=array($mb_no);
        }else{
            $sql="select ? from shop_member where index_no=?";
            $data=array($fileds,$mb_no);
        }
        return $this->ci->Query_model->returnOneArr($sql,$data);
    }
    // 회원의 정보를 리턴
    function get_member($mb_id, $fileds='*'){
        #return sql_fetch("select $fileds from shop_member where id = TRIM('$mb_id')");
        $sql="";
        $data=array();
        if($fileds=='*'){
            $sql="select * from shop_member where id = TRIM(?)";
            $data=array($mb_id);
        }else{
            $sql="select ? from shop_member where id = TRIM(?)";
            $data=array($fileds,$mb_id);
        }
        return $this->ci->Query_model->returnOneArr($sql,$data);
    }
    // 회원레벨 인덱스번호 체크
    function get_grade($gb_no){
        #$row = sql_fetch("select * from shop_member_grade where gb_no = '$gb_no'");
        $sql="select * from shop_member_grade where gb_no = ?";
        $data=array($gb_no);
        $row = $this->ci->Query_model->returnOneArr($sql,$data);
        $gb_name = $row['gb_name'];

        return $gb_name;
    }
    // 사용포인트 입력
    function insert_use_point($mb_id, $point, $po_id=''){
        $point1 = abs($point);
        #$sql = " select po_id, po_point, po_use_point from shop_point where mb_id = '$mb_id' and po_id <> '$po_id' and po_point > po_use_point order by po_id asc ";
        $sql = " select po_id, po_point, po_use_point from shop_point where mb_id = ? and po_id <> ? and po_point > po_use_point order by po_id asc ";
        $data=array($mb_id,$po_id);
        $result=$this->ci->Query_model->returnArr($sql,$data);
        foreach($result as $key => $row){
            $point2 = $row['po_point'];
            $point3 = $row['po_use_point'];
            if(($point2 - $point3) > $point1) {
                #$sql = " update shop_point set po_use_point = po_use_point + '$point1' where po_id = '{$row['po_id']}' ";
                #sql_query($sql);
                $sql2 = " update shop_point set po_use_point = po_use_point + ? where po_id = ? ";
                $data2=array($point1,$row['po_id']);
                $this->ci->Query_model->returnNull($sql2,$data2);
                break;
            }else{
                $point4 = $point2 - $point3;
                #$sql = " update shop_point set po_use_point = po_use_point + '$point4' where po_id = '{$row['po_id']}' ";
                #sql_query($sql);
                $sql2 = " update shop_point set po_use_point = po_use_point + ? where po_id = ? ";
                $data2=array($point4,$row['po_id']);
                $this->ci->Query_model->returnNull($sql2,$data2);
                $point1 -= $point4;
            }
        }
        #$result = sql_query($sql);
        /*for($i=0; $row=sql_fetch_array($result); $i++) {
            $point2 = $row['po_point'];
            $point3 = $row['po_use_point'];

            if(($point2 - $point3) > $point1) {
                $sql = " update shop_point
                            set po_use_point = po_use_point + '$point1'
                        where po_id = '{$row['po_id']}' ";
                sql_query($sql);
                break;
            } else {
                $point4 = $point2 - $point3;
                $sql = " update shop_point
                            set po_use_point = po_use_point + '$point4'
                        where po_id = '{$row['po_id']}' ";
                sql_query($sql);
                $point1 -= $point4;
            }
        }*/
    }
    // 사용포인트 삭제
    function delete_use_point($mb_id, $point){
        $point1 = abs($point);
        #$sql = " select po_id, po_use_point from shop_point where mb_id = '$mb_id' and po_use_point > 0 order by po_id desc ";
        #$result = sql_query($sql);
        $sql = " select po_id, po_use_point from shop_point where mb_id = ? and po_use_point > 0 order by po_id desc ";
        $data=array($mb_id);
        $result=$this->ci->Query_model->returnArr($sql,$data);
        foreach($result as $key => $row){
            $point2 = $row['po_use_point'];

            if($point2 > $point1) {
                #$sql = " update shop_point set po_use_point = po_use_point - '$point1' where po_id = '{$row['po_id']}' ";
                #sql_query($sql);
                $sql2 = " update shop_point set po_use_point = po_use_point - ? where po_id = ? ";
                $data2=array($point1,$row['po_id']);
                $this->ci->Query_model->returnNull($sql2,$data2);
                break;
            } else {
                #$sql = " update shop_point set po_use_point = '0' where po_id = '{$row['po_id']}' ";
                #sql_query($sql);
                $sql2 = " update shop_point set po_use_point = '0' where po_id = ? ";
                $data2=array($row['po_id']);
                $this->ci->Query_model->returnNull($sql2,$data2);

                $point1 -= $point2;
            }
        }
        /*for($i=0; $row=sql_fetch_array($result); $i++) {
            $point2 = $row['po_use_point'];

            if($point2 > $point1) {
                $sql = " update shop_point
                            set po_use_point = po_use_point - '$point1'
                        where po_id = '{$row['po_id']}' ";
                sql_query($sql);
                break;
            } else {
                $sql = " update shop_point
                            set po_use_point = '0'
                        where po_id = '{$row['po_id']}' ";
                sql_query($sql);

                $point1 -= $point2;
            }
        }*/
    }
    // 포인트 내역 합계
    function get_point_sum($mb_id){
        // 포인트합
        #$sql = " select sum(po_point) as sum_po_point from shop_point where mb_id = '$mb_id' ";
        #$row = sql_fetch($sql);
        $sql = " select sum(po_point) as sum_po_point from shop_point where mb_id = ? ";
        $data=array($mb_id);
        $row=$this->ci->Query_model->returnOneArr($sql,$data);
        return (int)$row['sum_po_point'];
    }
    // 상품 진열,1
    function display_itemtype($mb_id, $type, $rows=''){
        /*$sql = " select a.* from shop_goods a left join shop_goods_type b on (a.index_no=b.gs_id) where b.mb_id = '$mb_id'
                    and a.shop_state = '0'
                    and a.isopen IN ('1','2')
                    and find_in_set('$mb_id', a.use_hide) = '0'
                    and b.it_type{$type} = '1'
                    order by a.index_no desc ";*/
        #$result = sql_query($sql);
        #$type_count = sql_num_rows($result);
        $sql = " select a.* from shop_goods a left join shop_goods_type b on (a.index_no=b.gs_id) where b.mb_id = ?
                    and a.shop_state = '0'
                    and a.isopen IN ('1','2')
                    and find_in_set(?, a.use_hide) = '0'
                    and b.it_type{$type} = '1'
                order by a.index_no desc ";
        $data=array($mb_id,$mb_id);
        if($rows){
            $sql .= " limit ? ";
            array_push($data,$rows);
        } 
        $result=$this->ci->Query_model->returnQueryObj($sql,$data);
        $type_count = $result->num_rows();
        if(!$type_count && $mb_id != 'admin') {
            /*$sql = " select a.*
                    from shop_goods a left join shop_goods_type b on (a.index_no=b.gs_id)
                    where b.mb_id = 'admin'
                        and a.shop_state = '0'
                        and a.isopen IN ('1','2')
                        and find_in_set('$mb_id', a.use_hide) = '0'
                        and b.it_type{$type} = '1'
                    order by a.index_no desc ";*/
            $sql = " select a.* from shop_goods a left join shop_goods_type b on (a.index_no=b.gs_id) where b.mb_id = 'admin'
                        and a.shop_state = '0'
                        and a.isopen IN ('1','2')
                        and find_in_set(?, a.use_hide) = '0'
                        and b.it_type{$type} = '1'
                    order by a.index_no desc ";
            $data=array($mb_id);
            if($rows){ 
                $sql .= " limit $rows ";
                array_push($data,$rows);
            }
            #$result = sql_query($sql);
            $result = $this->ci->Query_model->returnArr($sql);
        }
        return $result;
    }
    // 상품 진열,2
    function query_itemtype($mb_id, $type, $sql_search, $sql_order){
        /*$sql = " select a.*
                from shop_goods a left join shop_goods_type b on (a.index_no=b.gs_id)
                where b.mb_id = '$mb_id'
                    and a.shop_state = '0'
                    and a.isopen IN ('1','2')
                    and find_in_set('$mb_id', a.use_hide) = '0'
                    and b.it_type{$type} = '1'
                    {$sql_search}
                    {$sql_order} ";
        $result = sql_query($sql);*/
        $sql = " select a.* from shop_goods a left join shop_goods_type b on (a.index_no=b.gs_id) where b.mb_id = ?
                    and a.shop_state = '0' and a.isopen IN ('1','2') and find_in_set(?, a.use_hide) = '0'
                    and b.it_type{$type} = '1' ? ? ";
        $data=array($mb_id,$mb_id,$sql_search,$sql_order);
        $result=$this->ci->Query_model->returnQueryObj($sql,$data);
        #$type_count = sql_num_rows($result);
        $type_count = $result->num_rows();
        if(!$type_count && $mb_id != 'admin') {
            /*$sql = " select a.*
                    from shop_goods a left join shop_goods_type b on (a.index_no=b.gs_id)
                    where b.mb_id = 'admin'
                        and a.shop_state = '0'
                        and a.isopen IN ('1','2')
                        and find_in_set('$mb_id', a.use_hide) = '0'
                        and b.it_type{$type} = '1'
                        {$sql_search}
                        {$sql_order} ";
            $result = sql_query($sql);*/
            $sql = " select a.*
                    from shop_goods a left join shop_goods_type b on (a.index_no=b.gs_id)
                    where b.mb_id = 'admin'
                        and a.shop_state = '0'
                        and a.isopen IN ('1','2')
                        and find_in_set(?, a.use_hide) = '0'
                        and b.it_type{$type} = '1' ? ?";
            $data=array($mb_id,$sql_search,$sql_order);
            $result=$this->ci->Query_model->returnArr($sql,$data);
        }
        return $result;
    }
    // 공급사 정보를 리턴
    function get_seller($mb_id, $fileds='*'){
        if($fileds=="*"){
            $sql="select * from shop_seller where mb_id = TRIM(?)";
            $data=array($mb_id);
        }else{
            $sql="select ? from shop_seller where mb_id = TRIM(?)";
            $data=array($fileds,$mb_id);
        }
        return $this->ci->Query_model->returnOneArr($sql,$data);
        #return sql_fetch("select $fileds from shop_seller where mb_id = TRIM('$mb_id')");
    }
    // 공급사 정보를 리턴
    function get_seller_cd($code, $fileds='*'){
        if($fileds=="*"){
            $sql="select * from shop_seller where seller_code = TRIM(?)";
            $data=array($code);
        }else{
            $sql="select ? from shop_seller where seller_code = TRIM(?)";
            $data=array($fileds,$code);
        }
        return $this->ci->Query_model->returnOneArr($sql,$data);
        #return sql_fetch("select $fileds from shop_seller where seller_code = TRIM('$code')");
    }
    // 공급업체 유일키검사
    function code_uniqid(){
        for($i=100001; $i<=999999; $i++) {
            $code = 'AP-'.sprintf("%06d", $i);

            // 주문서에 탈퇴한 공급사코드가 있는지 검사
            #$sql = " select count(*) as cnt from shop_order where seller_id = '$code' ";
            #$row = sql_fetch($sql);
            $sql = " select count(*) as cnt from shop_order where seller_id = ? ";
            $data=array($code);
            $row=$this->ci->Query_model->returnOneArr($sql,$data);
            if($row['cnt']) // 있다면 건너뛴다.
                continue;

            #$sql = " select count(*) as cnt from shop_seller where seller_code = '$code' ";
            #$row = sql_fetch($sql);
            $sql = " select count(*) as cnt from shop_seller where seller_code = ? ";
            $row=$this->ci->Query_model->returnOneArr($sql,$data);
            if(!$row['cnt']) { // 없다면 빠진다.
                return $code;
                break;
            }

            // count 하지 못했으면 일정시간 쉰다음 다시 유일키를 검사한다.
            usleep(10000); // 100분의 1초를 쉰다
        }
        return '';
    }
    // 옵션의 재고 (창고재고수량)
    function get_option_stock_qty($gs_id, $io_id, $type){
        /*$sql = " select io_stock_qty
                    from shop_goods_option
                    where gs_id = '$gs_id'
                    and io_id = '$io_id'
                    and io_type = '$type'
                    and io_use = '1' ";
        $row = sql_fetch($sql);*/
        $sql = " select io_stock_qty
                    from shop_goods_option
                    where gs_id = ?
                    and io_id = ?
                    and io_type = ?
                    and io_use = '1' ";
        $data=array($gs_id,$io_id,$type);
        $row=$this->ci->Query_model->returnOneArr($sql,$data);
        $jaego = (int)$row['io_stock_qty'];
        return $jaego;
    }
    // 주문서별 실입금액 합계
    function get_order_ipgum($od_id){
        #$sql = " select SUM(use_price) as useprice from shop_order where od_id = '$od_id' ";
        #$row = sql_fetch($sql);
        $sql = " select SUM(use_price) as useprice from shop_order where od_id = ? ";
        $data=array($od_id);
        $orw=$this->ci->Query_model->returnOneArr($sql,$data);

        return $row;
    }
    // 주문서별 총합계
    function get_order_spay($od_id, $sql_search=''){
        /*$sql = " select SUM(goods_price) as price,
                        SUM(baesong_price) as baesong,
                        SUM(goods_price + baesong_price) as buyprice,
                        SUM(supply_price) as supply,
                        SUM(cancel_price) as cancel,
                        SUM(refund_price) as refund,
                        SUM(coupon_price) as coupon,
                        SUM(use_point) as usepoint,
                        SUM(use_price) as useprice,
                        SUM(sum_qty) as qty,
                        SUM(sum_point) as point
                from shop_order
                where od_id = '$od_id'
                    {$sql_search} ";
        $row = sql_fetch($sql);*/
        $sql = " select SUM(goods_price) as price,
                        SUM(baesong_price) as baesong,
                        SUM(goods_price + baesong_price) as buyprice,
                        SUM(supply_price) as supply,
                        SUM(cancel_price) as cancel,
                        SUM(refund_price) as refund,
                        SUM(coupon_price) as coupon,
                        SUM(use_point) as usepoint,
                        SUM(use_price) as useprice,
                        SUM(sum_qty) as qty,
                        SUM(sum_point) as point
                from shop_order
                where od_id = ? {$sql_search} ";
        $data=array($od_id);
        $row=$this->ci->Query_model->returnOneArr($sql,$data);
        return $row;
    }
    // 주문정보 주문번호
    function get_order($order_id, $fileds='*'){
        if(strlen($order_id) < 14)
            $sql_where = " where od_no = ?"; // 주문일련번호
        else
            $sql_where = " where od_id = ?"; // 주문번호

        if($fileds=="*"){
            $sql="select * from shop_order ?";
            $data=array($sql_where,$order_id);
        }else{
            $sql="select ? from shop_order ?";
            $data=array($fileds,$sql_where,$order_id);
        }
        return $this->ci->Query_model->returnOneArr($sql,$data);
        #return sql_fetch(" select $fileds from shop_order {$sql_where} ");
    }
    // 신규가입 쿠폰일경우 다시 사용할 수 있도록 돌려준다.
    function subtract_coupon_log($od_no){
        #$sql = " select lo_id from shop_coupon_log where od_no = '$od_no' and cp_type = '5' ";
        #$row = sql_fetch($sql);
        $sql = " select lo_id from shop_coupon_log where od_no = ? and cp_type = '5' ";
        $data=array($od_no);
        $row=$this->ci->Query_model->returnOneArr($sql,$data);
        if($row['lo_id']) {
            /*$sql = " update shop_coupon_log
                        set mb_use = '0'
                        , od_no = ''
                        , cp_udate = ''
                    where lo_id = '{$row['lo_id']}' ";
            sql_query($sql, FALSE);*/
            $sql = " update shop_coupon_log
                        set mb_use = '0'
                        , od_no = ''
                        , cp_udate = ''
                    where lo_id = ?";
            $data=array($row['lo_id']);
            $this->ci->Query_model->returnNull($sql,$data);
        }
    }
    // 상품옵션별재고 또는 상품재고에 더하기
    function add_io_stock($gs_id, $od_id){
        #$sql = " select * from shop_cart where od_id = '$od_id' and gs_id= '{$gs_id}'";
        #$res = sql_query($sql);
        $sql = " select * from shop_cart where od_id = ? and gs_id= ?";
        $data=array($od_id,$gs_id);
        $res=$this->ci->Query_model->returnArr($sql,$data);
        foreach($res as $key => $ct){
            if($ct['io_id']) { // 옵션 : 재고수량 증가
                /*$sql = " update shop_goods_option
                            set io_stock_qty = io_stock_qty + '{$ct['ct_qty']}'
                        where io_id = '{$ct['io_id']}'
                            and gs_id = '{$ct['gs_id']}'
                            and io_type = '{$ct['io_type']}'
                            and io_stock_qty <> '999999999' ";
                sql_query($sql, FALSE);*/
                $sql = " update shop_goods_option
                            set io_stock_qty = io_stock_qty + ?
                        where io_id = ?
                            and gs_id = ?
                            and io_type = ?
                            and io_stock_qty <> '999999999' ";
                $data=array($ct['ct_qty'],$ct['io_id'],$ct['gs_id'],$ct['io_type']);
                $this->ci->Query_model->returnNull($sql,$data);
            } else { // 상품 : 재고수량 증가
                /*$sql = " update shop_goods
                            set stock_qty = stock_qty + '{$ct['ct_qty']}'
                        where index_no = '{$ct['gs_id']}'
                            and stock_mod = '1' ";
                sql_query($sql, FALSE);*/
                $sql = " update shop_goods
                            set stock_qty = stock_qty + ?
                        where index_no = ?
                            and stock_mod = '1' ";
                $data=array($ct['ct_qty'],$ct['gs_id']);
                $this->ci->Query_model->returnNull($sql,$data);
            }
        }
        /*while($ct=sql_fetch_array($res)) {
            if($ct['io_id']) { // 옵션 : 재고수량 증가
                $sql = " update shop_goods_option
                            set io_stock_qty = io_stock_qty + '{$ct['ct_qty']}'
                        where io_id = '{$ct['io_id']}'
                            and gs_id = '{$ct['gs_id']}'
                            and io_type = '{$ct['io_type']}'
                            and io_stock_qty <> '999999999' ";
                sql_query($sql, FALSE);
            } else { // 상품 : 재고수량 증가
                $sql = " update shop_goods
                            set stock_qty = stock_qty + '{$ct['ct_qty']}'
                        where index_no = '{$ct['gs_id']}'
                            and stock_mod = '1' ";
                sql_query($sql, FALSE);
            }
        }*/
    }
    // 상품 판매수량 반영
    function add_sum_qty($gs_id){
        // 배송완료 된 상품만 수량을 더한다.
        #$sql = " select sum(sum_qty) as it_sum_qty from shop_order where gs_id = '$gs_id' and dan IN(5,8) ";
        #$row = sql_fetch($sql);
        $sql = " select sum(sum_qty) as it_sum_qty from shop_order where gs_id = ? and dan IN(5,8) ";
        $data=array($gs_id);
        $row=$this->ci->Query_model->returnOneArr($sql,$data);

        #$sql = " update shop_goods set sum_qty = '{$row['it_sum_qty']}' where index_no = '$gs_id' ";
        #sql_query($sql);
        $sql = " update shop_goods set sum_qty = ? where index_no = ?";
        $data=array($row['it_sum_qty'],$gs_id);
        $this->ci->Query_model->returnNull($sql,$data);
    }
    // '배송완료' > '구매확정' 상태로 변경
    function change_status_final($od_no){
        $OM_TIME_YMDHIS=$this->OM_TIME_YMDHIS;
        // $sql = " update shop_order
        //             set user_ok = '1'
        //             , user_date = '".OM_TIME_YMDHIS."'
        //         where od_no = '$od_no'
        //             and user_ok = '0'
        //             and dan = '5' ";
        // sql_query($sql);
        $sql = " update shop_order set user_ok = '1', user_date = ? where od_no = ? and user_ok = '0' and dan = '5' ";
        $data=array($OM_TIME_YMDHIS,$od_no);
        $this->ci->Query_model->returnNull($sql,$data);
    }
    // '구매확정' > '구매확정취소' 상태로 변경
    function change_status_final_cancel($od_no){
        /*
        $sql = " update shop_order
                    set user_ok = '0'
                    , user_date = '0000-00-00 00:00:00'
                where od_no = '$od_no'
                    and user_ok = '1'
                    and dan = '5' ";
        sql_query($sql);
        */
        $sql = " update shop_order
                    set user_ok = '0'
                    , user_date = '0000-00-00 00:00:00'
                where od_no = ?
                    and user_ok = '1'
                    and dan = '5' ";
        $data=array($od_no);
        $this->ci->Query_model->returnNull($sql,$data);
    }
    // '입금대기' 상태로 변경
    function change_order_status_1($od_no){
        /*$sql = " update shop_order
                    set dan = '1'
                    , receipt_time = '0000-00-00 00:00:00'
                where od_no = '$od_no'
                    and dan = '2' ";
        sql_query($sql);*/
        $sql = " update shop_order
                    set dan = '1'
                    , receipt_time = '0000-00-00 00:00:00'
                where od_no = ?
                    and dan = '2' ";
        $data=array($od_no);
        $this->ci->Query_model->returnNull($sql,$data);
    }
    // '입금완료' 상태로 변경 (일련번호)
    function change_order_status_2($od_no){
        $OM_TIME_YMDHIS=$this->OM_TIME_YMDHIS;
        // $sql = " update shop_order
        //             set dan = '2'
        //             , receipt_time = '".OM_TIME_YMDHIS."'
        //         where od_no = '$od_no'
        //             and dan = '1' ";
        // sql_query($sql);
        $sql = " update shop_order
                    set dan = '2'
                    , receipt_time = ?
                where od_no = ?
                    and dan = '1' ";
        $data=array($OM_TIME_YMDHIS,$od_no);
        $this->ci->Query_model->returnNull($sql,$data);
    }
    // '입금완료' 상태로 변경 (주문번호)
    function change_order_status_ipgum($od_id){
        $OM_TIME_YMDHIS=$this->OM_TIME_YMDHIS;
        // $sql = " update shop_order
        //             set dan = '2'
        //             , receipt_time = '".OM_TIME_YMDHIS."'
        //         where od_id = '$od_id'
        //             and dan = '1' ";
        //sql_query($sql);
        $sql = " update shop_order
                    set dan = '2'
                    , receipt_time = ?
                where od_id = ?
                    and dan = '1' ";
        $data=array($OM_TIME_YMDHIS,$od_id);
        $this->ci->Query_model->returnNull($sql,$data);
    }
    // '배송준비' 상태로 변경
    function change_order_status_3($od_no, $delivery='', $delivery_no=''){
        // $sql = " update shop_order
        //             set dan = '3'
        //             , delivery = '$delivery'
        //             , delivery_no = '$delivery_no'
        //         where od_no = '$od_no' ";
        // sql_query($sql);
        $sql = " update shop_order
                    set dan = '3'
                    , delivery = ?
                    , delivery_no = ?
                where od_no = ? ";
        $data=array($delivery,$delivery_no,$od_no);
        $this->ci->Query_model->returnNull($sql,$data);
    }
    // '배송중' 상태로 변경
    function change_order_status_4($od_no, $delivery='', $delivery_no=''){
        $OM_TIME_YMDHIS=$this->OM_TIME_YMDHIS;
        // $sql = " update shop_order
        //             set dan = '4'
        //             , delivery_date = '".OM_TIME_YMDHIS."'
        //             , delivery = '$delivery'
        //             , delivery_no = '$delivery_no'
        //         where od_no = '$od_no' ";
        // sql_query($sql);
        $sql = " update shop_order
                    set dan = '4'
                    , delivery_date = ?
                    , delivery = ?
                    , delivery_no = ?
                where od_no = ? ";
        $data=array($OM_TIME_YMDHIS,$delivery,$delivery_no,$od_no);
        $this->ci->Query_model->returnNull($sql,$data);
    }
    // '배송후 교환' 상태로 변경
    function change_order_status_8($od_no){
        $OM_TIME_YMDHIS=$this->OM_TIME_YMDHIS;
        // $sql = " update shop_order
        //             set dan = '8'
        //             , change_date = '".OM_TIME_YMDHIS."'
        //         where od_no = '$od_no' ";
        // sql_query($sql);
        $sql = " update shop_order
                    set dan = '8'
                    , change_date = ?
                where od_no = ? ";
        $data=array($OM_TIME_YMDHIS,$od_no);
        $this->ci->Query_model->returnNull($sql,$data);
    }
    // 게시판설정
    function get_board($boardid){
        #return sql_fetch("select * from shop_board_conf where index_no='$boardid'");
        $sql="select * from shop_board_conf where index_no=?";
        $data=array($boardid);
        return $this->ci->Query_model->returnOneArr($sql,$data);
    }
    // 카테고리
    function get_cate($catecode){
        #return sql_fetch("select * from shop_category where catecode='$catecode'");
        $sql="select * from shop_category where catecode=?";
        $data=array($catecode);
        return $this->ci->Query_model->returnOneArr($sql,$data);
    }
    // 카테고리 이름
    function get_catename($code){
        // $row = sql_fetch("select catename from shop_category where catecode='$code'");
        $sql="select catename from shop_category where catecode=?";
        $data=array($code);
        $row=$this->ci->Query_model->returnOneArr($sql,$data);
        return $row['catename'];
    }
    // 장바구니의 정보를 리턴.
    // $idnex는 장바구니 주키 값
    function get_cart_id($cart_id){
        #return sql_fetch("select * from shop_cart where index_no='$cart_id'");
        $sql="select * from shop_cart where index_no=?";
        $data=array($cart_id);
        return $this->ci->Query_model->returnOneArr($sql,$data);
    }
    // 장바구니의 정보를 리턴.
    // $od_no는 장바구니 주문번호
    function get_shop_cart($od_no){
        #return sql_fetch("select * from shop_cart where od_no='$od_no'");
        $sql="select * from shop_cart where od_no=?";
        $data=array($od_no);
        return $this->ci->Query_model->returnOneArr($sql,$data);
    }
    // 상품 정보의 배열을 리턴
    function get_goods($gs_id, $fileds='*'){
        #return sql_fetch(" select $fileds from shop_goods where index_no='$gs_id'" );
        if($fileds=="*"){
            $sql="select * from shop_goods where index_no=?";
            $data=array($gs_id);
        }else{
            $sql="select ? from shop_goods where index_no=?";
            $data=array($fileds,$gs_id);    
        }
        
        return $this->ci->Query_model->returnOneArr($sql,$data);
    }
    // 상품 브랜드주키 정보의 배열을 리턴
    function get_brand($br_id){
        #$br = sql_fetch("select br_id,br_name from shop_brand where br_id='$br_id'" );
        $sql="select br_id,br_name from shop_brand where br_id=?";
        $data=array($br_id);
        $br=$this->ci->Query_model->returnOneArr($sql,$data);
        if($br['br_id'])
            $br_name = $br['br_name'];

        return $br_name;
    }
    // 인기검색어 입력
    function insert_popular($pt_id, $str){
        if(!$str) return;
        $OM_TIME_YMDHIS=$this->OM_TIME_YMDHIS;
        $agent = strtolower($_SERVER['HTTP_USER_AGENT']);
        if(!preg_match("/bot|slurp/", $agent)) {
            #$sql = " insert into shop_popular set pt_id = '{$pt_id}', pp_word = '{$str}', pp_date = '".OM_TIME_YMD."', pp_ip = '{$_SERVER['REMOTE_ADDR']}' ";
            #sql_query($sql, FALSE);
            $sql = " insert into shop_popular set pt_id = ?, pp_word = ?, pp_date = ?, pp_ip = ?";
            $data=array($pt_id,$str,$OM_TIME_YMDHIS,$_SERVER['REMOTE_ADDR']);
            $this->ci->Query_model->returnNull($sql,$data);
        }
    }
    // 게시판의 다음글 번호를 얻는다.
    function get_next_num($table){
        // 가장 큰 번호를 얻어
        #$sql = " select max(index_no) as max_num from $table ";
        #$row = sql_fetch($sql);
        $sql = " select max(index_no) as max_num from {$table} ";
        $row=$this->ci->Query_model->returnOneArr($sql);
        // 가장 큰 번호에 1을 더해서 넘겨줌
        return (int)($row['max_num'] + 1);
    }
    // 다음글 번호를 얻는다.
    function get_next_wr_num($table, $val, $option=''){
        // 가장 큰 번호를 얻어
        // $sql = " select max($val) as max_num from $table $option ";
        // $row = sql_fetch($sql);
        $sql = "select max(?) as max_num from {$table} {$option}";
        $data=array($val);
        $row=$this->ci->Query_model->returnOneArr($sql,$data);
        // 가장 큰 번호에 1을 더해서 넘겨줌
        return (int)($row['max_num'] + 1);
    }
    // 특정필드는 제외
    function get_columns($tablename){
        $columns = array();
        #$res = sql_query("SHOW COLUMNS FROM {$tablename}");
        $sql="SHOW COLUMNS FROM {$tablename}";
        $res=$this->ci->Query_model->returnArr($sql);
        foreach($res as $key => $row){
            $columns[] = "`".$row["Field"]."`";
        }
        // while($row=sql_fetch_array($res)) {
        //     $columns[] = "`".$row["Field"]."`";
        // }
        return $columns;
    }
    // 본인확인내역 기록
    function insert_cert_history($mb_id, $company, $method){
        $OM_TIME_YMD=$this->OM_TIME_YMD;
        $OM_TIME_HIS=$this->OM_TIME_HIS;
        /*
            $sql = " insert into shop_cert_history
                        set mb_id = '$mb_id',
                            cr_company = '$company',
                            cr_method = '$method',
                            cr_ip = '{$_SERVER['REMOTE_ADDR']}',
                            cr_date = '".OM_TIME_YMD."',
                            cr_time = '".OM_TIME_HIS."' ";
            sql_query($sql);
        */
        $sql = " insert into shop_cert_history set mb_id = ?,cr_company = ?,cr_method = ?,cr_ip = ?,cr_date = ?,cr_time = ? ";
        $data=array($mb_id,$company,$method,$_SERVER['REMOTE_ADDR'],$OM_TIME_YMD,$OM_TIME_HIS);
        $this->ci->Query_model->returnNull($sql,$data);
    }
    function sql_password($value){
        // mysql 4.0x 이하 버전에서는 password() 함수의 결과가 16bytes
        // mysql 4.1x 이상 버전에서는 password() 함수의 결과가 41bytes
        $sql="select version() as v";
        $rows=$this->ci->Query_model->returnOneArr($sql);
        // mysql 버전이 5.7보다 클 경우
        if(version_compare($rows['v'], '5.7.34') > 0){
            // 5.7버전 이후부터 passord 함수가 없음
            $row = $this->ci->Query_model->returnOneArr(" select CONCAT('*', UPPER(SHA1(UNHEX(SHA1('$value'))))) as pass ");
        }else{
            $row = $this->ci->Query_model->returnOneArr(" select password('$value') as pass ");
        }

        return $row['pass'];
    }
}
###쿼리문 들어가 있는 것 끝

?>