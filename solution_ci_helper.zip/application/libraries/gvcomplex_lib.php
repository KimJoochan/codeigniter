<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
#함수와 함수연결, 글로벌 변수까지 사용하는 함수들의 집합체
class gvcomplex_lib {
    protected $ci;
    public function __construct(){
        $this->ci =& get_instance();
        $this->ci->load->library('user_agent');
        $this->ci->load->helper('global_helper');
        $this->ci->load->model('Query_model');
    }
     #함수와 글로벌 변수로만 이루어진 함수들   
        #coomon.lib.php에 있던 함수들

            // 날짜, 조회수의 경우 높은 순서대로 보여져야 하므로 $flag 를 추가
            // $flag : asc 낮은 순서 , desc 높은 순서
            // 제목별로 컬럼 정렬하는 QUERY STRING
            function subject_sort_link($col, $query_string){
                $filed=$this->ci->load->get_var('filed');
                $orderby=$this->ci->load->get_var('orderby');
                if($orderby == 'asc') {
                    $q2 = "&filed=$col&orderby=desc";
                } else {
                    $q2 = "&filed=$col&orderby=asc";
                }
                return "<a href=\"{$_SERVER['SCRIPT_NAME']}?{$query_string}{$q2}\">";
            }
            // 5차카테고리
            function tree_category($catecode){
                $pt_id=$this->ci->load->get_var('pt_id');
                $str = "";
                $t_catecode = $catecode;

                $sql_common = " from shop_category ";
                $sql_where  = " where cateuse = '0' and find_in_set( ? , catehide) = '0' ";
                $sql_order  = " order by caterank, catecode ";

                // $sql = " select count(*) as cnt {$sql_common} {$sql_where} and upcate = '$catecode' ";
                // $res = sql_fetch($sql);
                $sql = " select count(*) as cnt ? ? and upcate = ? ";
                $data=array($sql_common, $sql_where, $pt_id, $catecode);
                $res=$this->ci->Query_model->returnOneArr($sql,$data);
                if($res['cnt'] < 1) {
                    $catecode = substr($catecode,0,-3);
                }

                $mod = 5; // 1줄당 노출 수
                $li_width = (int)(100 / $mod);
                #$sql = "select * {$sql_common} {$sql_where} and upcate = '$catecode' {$sql_order} ";
                $sql_common=$this->ci->db->escape_str($sql_common);
                $sql = "select * {$sql_common} ? and upcate = ? ?";
                $data=array( $sql_where, $pt_id, $catecode,$sql_order);
                $result=$this->ci->Query_model->returnArr($sql,$data);
                #$result = sql_query($sql);
                foreach($result as $key => $row){
                    if($i==0) $str .= '<ul class="sub_tree">';

                    $addclass = "";
                    if($t_catecode==$row['catecode'])
                        $addclass = ' class="active"';

                    $href = base_url().'shop/list.php?ca_id='.$row['catecode'];
                    $str .= "<li style=\"width:{$li_width}%\"{$addclass}><a href=\"{$href}\">{$row['catename']}</a></li>";
                }
                /*
                    for($i=0; $row=sql_fetch_array($result); $i++) {
                        if($i==0) $str .= '<ul class="sub_tree">'.PHP_EOL;

                        $addclass = "";
                        if($t_catecode==$row['catecode'])
                            $addclass = ' class="active"';

                        $href = OM_SHOP_URL.'/list.php?ca_id='.$row['catecode'];
                        $str .= "<li style=\"width:{$li_width}%\"{$addclass}><a href=\"{$href}\">{$row['catename']}</a></li>".PHP_EOL;
                    }
                */

                if($i > 0) $str .= '</ul>';

                return $str;
            }
            //  송장번호 일괄등록시 배송추척 URL 추출 (본사, 업체 공용)
            function get_info_delivery($company){
                $config=$this->ci->load->get_var('config');
                if(!$company) return '';
                $fld = trim($company);
                $info = array_filter(explode(",",$config['delivery_company']));
                foreach($info as $k=>$v) {
                    $arr = explode("|",trim($info[$k]));
                    if(trim($arr[0]) == trim($company)){
                        $fld = trim($info[$k]);
                        break;
                    }
                }
                return $fld;
            }
            //  상품 상세페이지 구매하기, 장바구니, 찜 버튼
            function get_buy_button($msg, $gs_id){
                $gs=$this->ci->load->get_var('gs');
                $pt_id=$this->ci->load->get_var('pt_id');

                $str = "";
                for($i=1; $i<=3; $i++) {
                    switch($i){
                        case '1':
                            $sw_css = " wset";
                            $sw_name = "구매하기";
                            $sw_direct = "buy";
                            break;
                        case '2':
                            $sw_css = " grey";
                            $sw_name = "장바구니";
                            $sw_direct = "cart";
                            break;
                        case '3':
                            $sw_css = " bx-white";
                            $sw_name = "찜하기";
                            $sw_direct = "wish";
                            break;
                    }

                    if($msg) {
                        $str .= "<span><a href=\"javascript:alert('$msg');\" class=\"btn_large".$sw_css."\">".$sw_name."</a></span>";
                    } else {
                        if($sw_direct == "wish") {
                            $str .= "<span><a href=\"javascript:item_wish(document.fbuyform);\" class=\"btn_large".$sw_css."\">".$sw_name."</a></span>";
                        } else {
                            $str .= "<span><a href=\"javascript:fbuyform_submit('".$sw_direct."');\" class=\"btn_large".$sw_css."\">".$sw_name."</a></span>";
                        }
                    }
                }

                return $str;
            }
            function get_seller_name($mb_id){
                $config=$this->ci->load->get_var('config');
                $sellerName = '';
                if(substr($mb_id,0,3) == 'AP-') {
                    #$row = sql_fetch("select company_name from shop_seller where seller_code = '$mb_id'");
                    $sql="select company_name from shop_seller where seller_code = ?";
                    $data=array($mb_id);
                    $row = $this->ci->Query_model->returnOneArr($sql,$data);
                    $sellerName = $row['company_name'];
                } else if($mb_id == 'admin') {
                    $sellerName = $config['company_name'];
                } else if($mb_id != 'admin') {
                    #$row = sql_fetch("select company_name from shop_partner where mb_id = '$mb_id'");
                    $sql="select company_name from shop_partner where mb_id = ?";
                    $data=array($mb_id);
                    $row=$this->ci->Query_model->returnOneArr($sql,$data);
                    $sellerName = $row['company_name'];
                }

                return $sellerName;
            }

        #global.lip.php에 있던 함수들
            // goo.gl 짧은주소 만들기
            function google_short_url($longUrl){
                $default=$this->ci->load->get_var('default');

                // Get API key from : http://code.google.com/apis/console/
                // URL Shortener API ON
                $apiKey = $default['de_googl_shorturl_apikey'];

                $postData = array('longUrl' => $longUrl, 'key' => $apiKey);
                $jsonData = json_encode($postData);

                $curlObj = curl_init();

                curl_setopt($curlObj, CURLOPT_URL, 'https://www.googleapis.com/urlshortener/v1/url?key=' . $apiKey);
                curl_setopt($curlObj, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($curlObj, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($curlObj, CURLOPT_HEADER, 0);
                curl_setopt($curlObj, CURLOPT_HTTPHEADER, array('Content-type:application/json'));
                curl_setopt($curlObj, CURLOPT_POST, 1);
                curl_setopt($curlObj, CURLOPT_POSTFIELDS, $jsonData);

                $response = curl_exec($curlObj);

                // Change the response json string to object
                $json = json_decode($response);

                curl_close($curlObj);

                return $json->id;
            }
            // 쿠폰 : 구매 가능한 상품
            function sql_coupon_log($lo_id){
                $member=$this->ci->load->get_var('member');

                // 쿠폰유효 기간 (시간대)
                $fr_hour = "(cp_inv_shour1 = '99' or cp_inv_shour1 <= date_format(now(),'%H'))";
                $to_hour = "(cp_inv_shour2 = '99' or cp_inv_shour2 > date_format(now(),'%H'))";

                $sql_common = " from shop_coupon_log ";
                $sql_where  = " where mb_id=? and mb_use='0' and lo_id=? ";
                $sql_where .= " and ((cp_inv_type='0' and (? and ?)) ";
                $sql_where .= " or (cp_inv_type='1' and date_add(`cp_wdate`, interval `cp_inv_day` day) > now())) ";

                #$row = sql_fetch(" select * $sql_common $sql_where ");
                $sql_common=$this->ci->db->escape_str($sql_common);
                $sql="select * {$sql_common} ?";
                $data=array($member['id'],$lo_id,$fr_hour,$to_hour,$sql_where);
                $row=$this->ci->Query_model->returnOneArr($sql,$data);

                switch($row['cp_use_part']) {
                    case '0': // 전체상품에 쿠폰사용 가능
                        $sql_search = "";
                        break;
                    case '1': // 일부 상품만 쿠폰사용 가능
                        if($row['cp_use_goods']) {
                            $sql_search = " and index_no IN($row[cp_use_goods]) ";
                        }
                        break;
                    case '2': // 일부 카테고리만 쿠폰사용 가능
                        if($row['cp_use_category']) {
                            $sql_search = " and ca_id IN($row[cp_use_category]) ";
                        }
                        break;
                    case '3': // 일부 상품은 쿠폰사용 불가
                        if($row['cp_use_goods']) {
                            $sql_search = " and index_no NOT IN($row[cp_use_goods]) ";
                        }
                        break;
                    case '4': // 일부 카테고리는 쿠폰사용 불가
                        if($row['cp_use_category']) {
                            $sql_search = " and ca_id NOT IN($row[cp_use_category]) ";
                        }
                        break;
                }

                return $sql_search;
            }
            // 출력멘트 리턴
            function get_head_title($fild, $mb_id){
                $config=$this->ci->load->get_var('config');
                #$row = sql_fetch("select $fild from shop_partner where mb_id='$mb_id' ");
                $sql="select ? from shop_partner where mb_id=?";
                $data=array($fild,$mb_id);
                $row = $this->ci->Query_model->returnOneArr($sql,$data);
                if(!$row[$fild])
                    $row[$fild] = $config[$fild];

                $str = $row[$fild];

                return $str;
            }
            // 관리자 체크.
            function is_admin($grade=''){
                $member=$this->ci->load->get_var('member');
                $grade = $grade ? $grade : $member['grade'];
                switch($grade){
                    case '1' :
                        return true;
                        break;
                    default :
                        return false;
                }
            }
            // 공급사인가?
            function is_seller($mb_id){
                $config=$this->ci->load->get_var('config');

                if(!$mb_id) return '';
                #$sr = sql_fetch("select state from shop_seller where mb_id = '$mb_id'");
                $sql="select state from shop_seller where mb_id = ?";
                $data=array($mb_id);
                $sr=$this->ci->Query_model->returnOneArr($sql,$data);

                if($config['shop_state'] == 0 && $sr['state']) {
                    return true;
                } else {
                    return false;
                }
            }
            // 장바구니에 담긴 상품수
            function get_cart_count(){
                $set_cart_id=$this->ci->load->get_var('set_cart_id');

                #$sql = " select * from shop_cart where ct_direct='$set_cart_id' and ct_select='0' group by gs_id ";
                #$result = sql_query($sql);
                #$cart_count = sql_num_rows($result);
                $sql = " select * from shop_cart where ct_direct=? and ct_select='0' group by gs_id ";
                $data=array($set_cart_id);
                $result=$this->ci->Query_model->returnQueryObj($sql,$data);
                $cart_count=$result->num_rows();
                return (int)$cart_count;
            }
            // 배송비를 구분자로 나눔 (주문폼으로 넘기기위한 작업)
            function get_tune_sendcost($com_array, $val_array){
                $item_sendcost=$this->ci->load->get_var('item_sendcost');

                if(!$item_sendcost)
                    return;

                $com = array();
                $val = array();
                for($i=0; $i<count($com_array); $i++) {
                    if(is_array($com_array[$i])) {
                        for($j=0; $j<count($com_array[$i]); $j++) {
                            $com[] = $com_array[$i][$j];
                            $val[] = $val_array[$i][$j];
                        }
                    } else {
                        $com[] = $com_array[$i];
                        $val[] = $val_array[$i];
                    }
                }

                // 배열 재정렬
                $dlcomb = array_combine($com,$val);

                // 빈 배열을 채움.
                $dltune = array();
                for($i=0; $i<count($item_sendcost); $i++) {
                    if($dlcomb[$i]) {
                        $dltune[$i] = $dlcomb[$i];
                    } else {
                        $dltune[$i] = 0;
                    }
                }

                return implode('|', $dltune);
            }
            // 상품 공통쿼리
            function sql_goods_list($sql_search=''){
                $pt_id=$this->ci->load->get_var('pt_id');
                $auth_good=$this->ci->load->get_var('auth_good');

                $pt_id=$this->ci->db->escape_str($pt_id); 
                if($auth_good) // 가맹점 상품판매권한이 있나?
                    $addsql = " or ( use_aff = '1' and mb_id = '$pt_id' ) ";
                
                $addsql=$this->ci->db->escape_str($addsql);
                $sql_search=$this->ci->db->escape_str($sql_search);

                $sql = " from shop_goods
                        where shop_state = '0'
                        and isopen IN('1','2')
                        and (use_aff = '0'{$addsql})
                        and find_in_set('$pt_id', use_hide) = '0'
                        {$sql_search} ";

                return $sql;
            }
            // 상품 검색쿼리
            function sql_goods_search($sql_search=''){
                $auth_good=$this->ci->load->get_var('auth_good');
                $pt_id=$this->ci->load->get_var('pt_id');
                $pt_id=$this->ci->db->escape_str($pt_id);

                if($auth_good) // 가맹점 상품판매권한이 있나?
                $addsql = " or ( a.use_aff = '1' and a.mb_id = '$pt_id' ) ";
                
                $addsql=$this->ci->db->escape_str($addsql);
                $sql_search=$this->ci->db->escape_str($sql_search);
                $sql = " from shop_goods a, shop_category b
                        where a.ca_id = b.catecode
                        and a.shop_state = '0'
                        and a.isopen IN('1','2')
                        and b.cateuse = '0'
                        and (a.use_aff = '0'{$addsql})
                        and find_in_set('$pt_id', a.use_hide) = '0'
                        and find_in_set('$pt_id', b.catehide) = '0'
                        {$sql_search} ";

                return $sql;
            }
            // 상품 가격정보의 배열을 리턴
            function get_sale_price($gs_id){
                $member=$this->ci->load->get_var('member');

                #$gb = sql_fetch("select * from shop_member_grade where gb_no = '$member[grade]'");
                #$gs = sql_fetch("select goods_price,use_aff from shop_goods where index_no = '$gs_id'");
                $sql="select * from shop_member_grade where gb_no = ?";
                $data=array($member['grade']);
                $gb=$this->ci->Query_model->returnOneArr($sql,$data);

                $sql2="select goods_price,use_aff from shop_goods where index_no = ?";
                $data2=array($gs_id);
                $gs=$this->ci->Query_model->returnOneArr($sql2,$data2);


                $price = $gs['goods_price'];

                if($gb['gb_sale'] > 0 && $member['id'] && !$gs['use_aff']) {
                    if($gb['gb_sale_rate'] == 1) // 금액으로 할인
                        $price = $gs['goods_price'] - $gb['gb_sale'];
                    else // 퍼센트로 할인
                        $price = $gs['goods_price'] - (($gs['goods_price'] / 100) * $gb['gb_sale']);

                    if(strlen($price) > 1 && $gb['gb_sale_unit'])
                        $price = floor((int)$price/(int)$gb['gb_sale_unit']) * (int)$gb['gb_sale_unit'];
                }

                return (int)$price;
            }

            // 연속배너 sql
            function sql_banner_rows($code, $mb_id){
                $config=$this->ci->load->get_var('config');
                $mk=$this->ci->load->get_var('mk');
                
                if($this->ci->agent->is_mobile()) // 모바일접속인가?
                    $sql_where = " where bn_device = 'mobile' and bn_theme = '{$mk['mobile_theme']}' ";
                else
                    $sql_where = " where bn_device = 'pc' and bn_theme = '{$mk['theme']}' ";
                

                $sql_where .= " and bn_code = ? and bn_use = '1' ";
                $sql_order  = " order by bn_order asc ";

                $sql_where=$this->ci->db->escape_str($sql_where);
                #$sql = " select * from shop_banner {$sql_where} and mb_id = '$mb_id' {$sql_order} ";
                $sql = " select * from shop_banner {$sql_where} and mb_id = ? {$sql_order}";
                $data=array($code,$mb_id);
                #$row = sql_fetch($sql);
                $row=$this->ci->Query_model->returnOneArr($sql,$data);
                if(!$row['bn_id'] && $mb_id != 'admin')
                    $sql = " select * from shop_banner {$sql_where} and mb_id = 'admin' {$sql_order} ";

                return $sql;
            }
            // 랜덤배너 sql
            function sql_banner($code, $mb_id){
                $config=$this->ci->load->get_var('config');
                $mk=$this->ci->load->get_var('mk');

                if($this->ci->agent->is_mobile()) // 모바일접속인가?
                    $sql_where = " where bn_device = 'mobile' and bn_theme = '{$mk['mobile_theme']}' ";
                else
                    $sql_where = " where bn_device = 'pc' and bn_theme = '{$mk['theme']}' ";

                $sql_where .= " and bn_code = ? and bn_use = '1' ";
                $sql_order  = " order by rand() limit 1 ";
                $sql_where=$this->ci->db->escape_str($sql_where);
                #$sql = " select * from shop_banner {$sql_where} and mb_id = '$mb_id' {$sql_order} ";
                $sql = " select * from shop_banner {$sql_where} and mb_id = ? {$sql_order} ";
                $data=array($code,$mb_id);
                #$row = sql_fetch($sql);
                $row=$this->ci->Query_model->returnOneArr($sql,$data);
                if(!$row['bn_id'] && $mb_id != 'admin')
                    $sql = " select * from shop_banner {$sql_where} and mb_id = 'admin' {$sql_order} ";

                return $sql;
            }
            // 찜하기
            function zzimCheck($gs_id){
                $member=$this->ci->load->get_var('member');

                #$sql = "select count(*) as cnt from shop_wish where mb_id='{$member['id']}' and gs_id='{$gs_id}' ";
                #$row =  sql_fetch($sql);
                $sql = "select count(*) as cnt from shop_wish where mb_id=? and gs_id=?";
                $data=array($member['id'],$gs_id);
                $row=$this->ci->Query_model->returnOneArr($sql,$data);

                return ($row['cnt']) ? "zzim on" : "zzim";
            }

            // 분류 쿼리
            function sql_query_cgy($upcate, $type='', $rows=''){
                $pt_id=$this->ci->load->get_var('pt_id');
                if($upcate == 'all')
                    $sql_search = " length(catecode) = '3' ";
                else
                    $sql_search = " upcate = '$upcate' and upcate <> '' ";

                $sql_search .= " and cateuse = '0' and find_in_set('$pt_id', catehide) = '0' ";

                if($type == 'COUNT') {
                    /*$sql = "select count(*) AS cnt
                            from shop_category
                            where {$sql_search} ";*/
                    $sql = "select count(*) AS cnt from shop_category where ? ";
                    $data=array($sql_search);
                    #return sql_fetch($sql);
                    return $this->ci->Query_model->returnOneArr($sql,$data);
                } else if($type == 'LIMIT') {
                    // $sql = "select *
                    //         from shop_category
                    //         where {$sql_search}
                    //         order by caterank, catecode limit {$rows}";
                    // return sql_query($sql);
                    $sql = "select * from shop_category  where ? order by caterank, catecode limit ?";
                    $data=array($sql_search,$rows);
                    return $this->ci->Query_model($sql,$data);
                } else {
                    // $sql = "select *
                    //         from shop_category
                    //         where {$sql_search}
                    //         order by caterank, catecode ";
                    // return sql_query($sql);
                    $sql = "select * from shop_category where ? order by caterank, catecode ";
                    $data=array($sql_search);
                    return $this->ci->Query_model->returnOneArr($sql,$data);
                }
            }

            function sql_field_names($table){
                $columns = array();

                #$sql = " select * from `$table` limit 1 ";
                #$result = sql_query($sql, $link);
                $table=$this->ci->db->escape_str($table);
                $sql = " select * from $table limit 1 ";
                $result=$this->ci->Query_model->returnOneArr($sql);
                foreach($result as $key => $row){
                    $columns[]= $key;
                }
                return $columns;
            }
            function add_stylesheet($stylesheet, $order=0){
                $this->ci->load->library('html_process');
                if(trim($stylesheet))
                    $this->ci->html_process->merge_stylesheet($stylesheet, $order);
            }
            function add_javascript($javascript, $order=0){
                $this->ci->load->library('html_process');
                if(trim($javascript))
                    $this->ci->html_process->merge_javascript($javascript, $order);
            }
        #mobile.lib.php에 있던 함수들
            // 5차카테고리
            function mobile_tree_category($catecode){
                $pt_id=$this->ci->load->get_var('pt_id');

                $t_catecode = $catecode;

                $sql_common = " from shop_category ";
                $sql_where  = " where cateuse = '0' and find_in_set('$pt_id', catehide) = '0' ";
                $sql_order  = " order by caterank, catecode ";

                #$sql = " select count(*) as cnt {$sql_common} {$sql_where} and upcate = '$catecode' ";
                #$res = sql_fetch($sql);
                $sql = " select count(*) as cnt {$sql_common} {$sql_where} and upcate = ? ";
                $data=array($catecode);
                $res=$this->ci->Query_model->returnOneArr($sql,$data);
                if($res['cnt'] < 1) {
                    $catecode = substr($catecode,0,-3);
                }

                #$sql = "select * {$sql_common} {$sql_where} and upcate = '$catecode' {$sql_order} ";
                $sql = "select * {$sql_common} {$sql_where} and upcate = ? {$sql_order} ";
                #$result = sql_query($sql);
                $result=$this->ci->Query_model->returnArr($sql,$data);
                foreach($result as $key => $row){
                    if($i==0) {
                        echo '<div id="sct_ct">';
                        echo '<ul>';
                    }
                    $addclass = "";
                    if($t_catecode==$row['catecode'])
                        $addclass = ' class="sct_here"';

                    $href = base_url().'m/shop/list.php?ca_id='.$row['catecode'];

                    echo "<li><a href=\"{$href}\"{$addclass}>{$row['catename']}</a></li>\n";
                }
                /*for($i=0; $row=sql_fetch_array($result); $i++) {
                    if($i==0) {
                        echo '<div id="sct_ct">'.PHP_EOL;
                        echo '<ul>'.PHP_EOL;
                    }

                    $addclass = "";
                    if($t_catecode==$row['catecode'])
                        $addclass = ' class="sct_here"';

                    $href = OM_MSHOP_URL.'/list.php?ca_id='.$row['catecode'];

                    echo "<li><a href=\"{$href}\"{$addclass}>{$row['catename']}</a></li>\n";
                }*/

                if($i > 0) {
                    echo '</ul>'.PHP_EOL;
                    echo '</div>'.PHP_EOL;
                }
            }
            //  상품 상세페이지 : 구매하기, 장바구니, 찜 버튼
            function mobile_buy_button($msg, $gs_id){                
                $gs=$this->ci->load->get_var('gs');
                $pt_id=$this->ci->load->get_var('pt_id');

                $ui_btn   = array("1"=>"구매하기","2"=>"장바구니","3"=>"찜하기");
                $ui_class = array("1"=>"btn_medium wset","2"=>"btn_medium bx-white","3"=>"btn_medium bx-white");

                $str = "<div class=\"sp_btn\">";
                for($i=1; $i<=3; $i++) {
                    switch($i){
                        case '1':
                            $sw_direct = "buy";
                            break;
                        case '2':
                            $sw_direct = "cart";
                            break;
                        case '3':
                            $sw_direct = "wish";
                            break;
                    }

                    if($msg) {
                        if($sw_direct == "buy") {
                            $str .= "<p><button type=\"button\" onclick=\"alert('$msg');\" class='$ui_class[$i]'>$ui_btn[$i]</button></p>";
                        } else {
                            $str .= "<span><button type=\"button\" onclick=\"alert('$msg');\" class='$ui_class[$i]'>$ui_btn[$i]</button></span>";
                        }
                    } else {
                        if($sw_direct == "wish") {
                            $str .= "<span><button type=\"button\" onclick=\"item_wish(document.fbuyform);\" class='$ui_class[$i]'>$ui_btn[$i]</button></span>";
                        } else if($sw_direct == "buy") {
                            $str .= "<p><button type=\"button\" onclick=\"fbuyform_submit('".$sw_direct."');\" class='$ui_class[$i]'>$ui_btn[$i]</button></p>";
                        } else {
                            $str .= "<span><button type=\"button\" onclick=\"fbuyform_submit('".$sw_direct."');\" class='$ui_class[$i]'>$ui_btn[$i]</button></span>";
                        }
                    }
                }

                $str .= "</div>";

                return $str;
            }
        #navberpay.lib.php에 있던 함수들
            function get_naverpay_return_info($mb_id){
                $config=$this->ci->load->get_var('config');
            
                $data = '';
                $address1 = trim($config['company_addr']);
                $address2 = ' ';
            
                $data .= '<returnInfo>';
                $data .= '<zipcode><![CDATA['.$config['company_zip'].']]></zipcode>';
                $data .= '<address1><![CDATA['.$address1.']]></address1>';
                $data .= '<address2><![CDATA['.$address2.']]></address2>';
                $data .= '<sellername><![CDATA['.$config['company_name'].']]></sellername>';
                $data .= '<contact1><![CDATA['.$config['company_tel'].']]></contact1>';
                $data .= '</returnInfo>';
            
                return $data;
            }
        #partner.lib.php
            // 만료일 기간연장
            function get_term_date($term='1'){
                $config=$this->ci->load->get_var('config');

                // 관리비를 사용중인가?
                if($config['pf_expire_use']) {
                    $term_date = date("Y-m-d", strtotime("+{$term} month", time()));
                } else {
                    $term_date = '9999-12-31';
                }

                return $term_date;
            }
            // 실제 도메인만 추출
            function get_basedomain($url){
                $config=$this->ci->load->get_var('config');
                // 모든 공백을 제거
                $basedomain = preg_replace("/\s+/", "", $config['pf_basedomain']);

                $value = strtolower(trim($url));
                $host="";
                if(preg_match('/^(?:(?:[0-9a-z_]+):\/\/)?((?:[0-9a-z_\d\-]{2,}\.)+[0-9a-z_]{2,})(?::\d{1,5})?(?:\/[^\?]*)?(?:\?.+)?$/i', $value)) {
                    preg_match('/([0-9a-z_\d\-]+(?:\.(?:'.$basedomain.')){1,2})(?::\d{1,5})?(?:\/[^\?]*)?(?:\?.+)?$/i', $value, $matches);
                    $host = (!$matches[1]) ? $value : $matches[1];
                }

                return $host;
            }
        #register.lib.php
            function reserve_mb_id($reg_mb_id){
                $config=$this->ci->load->get_var('config');

                if(preg_match("/[\,]?{$reg_mb_id}/i", $config['prohibit_id']))
                    return "이미 예약된 단어로 사용할 수 없는 회원아이디 입니다.";
                else
                    return "";
            }
            // 금지 메일 도메인 검사
            function prohibit_mb_email($reg_mb_email){
                $config=$this->ci->load->get_var('config');

                list($id, $domain) = explode("@", $reg_mb_email);
                $email_domains = explode("\n", trim($config['prohibit_email']));
                $email_domains = array_map('trim', $email_domains);
                $email_domains = array_map('strtolower', $email_domains);
                $email_domain = strtolower($domain);

                if(in_array($email_domain, $email_domains))
                    return "$domain 메일은 사용할 수 없습니다.";

                return "";
            }
    //함수와 글러벌 변수가 같이 섞여있는 함수들
}
?>