<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class register_lib {
    protected $ci;
    public function __construct(){
        $this->ci =& get_instance();
        $this->ci->load->model('Query_model');
        // Do something with $params
    }
    function exist_mb_id($reg_mb_id){
        $reg_mb_id = trim($reg_mb_id);
        if($reg_mb_id == "") return "";
        // $sql = " select count(*) as cnt from shop_member where id = '$reg_mb_id' ";
        // $row = sql_fetch($sql);
        $sql = " select count(*) as cnt from shop_member where id = ?";
        $data=array($reg_mb_id);
        $row=$this->ci->Query_model->returnOneArr($sql,$data);
        if($row['cnt'])
            return "이미 사용중인 회원아이디 입니다.";
        else
            return "";
    }
    function exist_mb_email($reg_mb_email, $reg_mb_id){
        // $row = sql_fetch(" select count(*) as cnt from shop_member where email = '$reg_mb_email' and id <> '$reg_mb_id' ");
        $sql=" select count(*) as cnt from shop_member where email = ? and id <> ?";
        $data=array($reg_mb_email),$reg_mb_id;
        $row=$this->ci->Query_model->returnOneArr($sql,$data);
        if($row['cnt'])
            return "이미 사용중인 E-mail 주소입니다.";
        else
            return "";
    }
?>