<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class upload_files{
    protected $upl_dir;
	protected $max_file_size;
	#function upload_files
	function index($upl_dir,$max_file_size){
		$this->upl_dir = $upl_dir;
		$this->max_file_size = $max_file_size;
	}

	function create_new_filename($filename, $is_srand=true){
		$pattern = "/[#\&\+\-%@=\/\\:;,'\"\^`~\|\!\?\*\$#<>\(\)\[\]\{\}]/";

		$filename = preg_replace("/\s+/", "", $filename);
		$filename = preg_replace($pattern, "", $filename);

		$filename = preg_replace_callback(
							  "/[가-힣]+/",
							  create_function('$matches', 'return base64_encode($matches[0]);'),
							  $filename);

		$filename = preg_replace($pattern, "", $filename);
		$prepend = '';

		if($is_srand) {
			$ext = $this->get_extension($filename);
			$new_filename = $this->new_chars_id().'.'.$ext;

			// 동일한 이름의 파일이 있으면 파일명 변경
			if(is_file($this->upl_dir.'/'.$new_filename)) {
				for($i=0; $i<20; $i++) {
					$prepend = str_replace('.', '_', microtime(true)).'_';

					if(is_file($this->upl_dir.'/'.$prepend.$new_filename)) {
						usleep(mt_rand(100, 10000));
						continue;
					} else {
						break;
					}
				}
			}

			$new_filename = $prepend.$new_filename;

		} else {
			$new_filename = $filename;
		}

		return $new_filename;
	}

	function upload(&$file){
		// 업로드 제한 파일타입 체크를 한다.
		$ext = $this->get_extension($file['name']);
		if(substr($file['type'],0,6) == 'images') {
			if(!$this->set_file_array($ext, 'img'))
				$this->set_error('허용되지 않은 파일입니다.');
		}
		else {
			if($this->set_file_array($ext, 'file'))
				$this->set_error('허용되지 않은 파일입니다.');
		}

		// 용량제한
		// if($file['size'] > $this->max_file_size)
		//	 $this->set_error("업로드 제한용량(".$this->max_file_size.")을 초과한 파일입니다.");

		if(!is_dir($this->upl_dir)) {
			@mkdir($this->upl_dir, OM_DIR_PERMISSION);
			@chmod($this->upl_dir, OM_DIR_PERMISSION);
		}

		// 파일명을 바꾸는 부분
		//if($ext == "ico") {
		//	$filename = $this->create_new_filename($file['name'], false);
		//} else {
		//	$filename = $this->create_new_filename($file['name'], true);
		//}

		$filename = $this->create_new_filename($file['name'], true);

		// 파일을 지정된 폴더로 이동시킨다.
		if(move_uploaded_file($file['tmp_name'], $this->upl_dir.'/'.$filename)) {
			@chmod($this->upl_dir.'/'.$filename, OM_FILE_PERMISSION);
			@unlink($file['tmp_name']);
			return $filename;
		} else {
			@unlink($file['tmp_name']);
			$this->set_error("업로드에 실패했습니다.");
		}
	}

	// 난수번호 생성함수
	function new_chars_id(){
		$len = 30;
		$chars = "abcdefghjklmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ123456789";

		srand((double)microtime()*1000000);

		$i = 0;
		$str = '';

		while($i < $len) {
			$num = rand() % strlen($chars);
			$tmp = substr($chars, $num, 1);
			$str .= $tmp;
			$i++;
		}

		return $str;
	}

	// 업로드 허용가능한 파일 검사
	function set_file_array($ext, $gubun){
		if($gubun == 'img') $arr_ext = array('gif','jpg','jpeg','png','ico');
		else $arr_ext = array('php','cgi','php3','ph3','ph','pl','html','htm','jsp','asp','js','ht');

		return in_array($ext, $arr_ext);
	}

	// 파일 확장자 추출
	function get_extension($filename){
		$array = explode(".", $filename);
		return strtolower($array[sizeof($array)-1]);
	}

	// 파일삭제
	function del($filename){
		if(!preg_match("/^(http[s]?:\/\/)/", $filename))
		{
			if(is_file($this->upl_dir.'/'.$filename) && $filename) {
				@unlink($this->upl_dir.'/'.$filename);
			}
		}
	}

	// Error Message
	function set_error($message){
		echo "<meta charset='utf-8'>";
		echo "<script>alert('".$message."');history.go(-1);</script>";
		exit;
	}
}