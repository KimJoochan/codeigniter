<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-15 09:42:24 --> Severity: error --> Exception: Call to undefined method stdClass::result_array() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 14
ERROR - 2021-09-15 09:59:49 --> Severity: error --> Exception: Call to undefined method Main::display_qty() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 14
ERROR - 2021-09-15 10:00:27 --> Severity: Notice --> Undefined variable: ci C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 336
ERROR - 2021-09-15 10:00:27 --> Severity: Notice --> Trying to get property 'db' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 336
ERROR - 2021-09-15 10:00:27 --> Severity: error --> Exception: Call to a member function query() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 336
ERROR - 2021-09-15 10:01:08 --> Severity: error --> Exception: syntax error, unexpected 'protected' (T_PROTECTED), expecting end of file C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 3
ERROR - 2021-09-15 10:01:44 --> Severity: Notice --> Undefined variable: ci C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 337
ERROR - 2021-09-15 10:01:44 --> Severity: Notice --> Trying to get property 'db' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 337
ERROR - 2021-09-15 10:01:44 --> Severity: error --> Exception: Call to a member function query() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 337
ERROR - 2021-09-15 10:01:50 --> Severity: Notice --> Undefined variable: ci C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 337
ERROR - 2021-09-15 10:01:50 --> Severity: Notice --> Trying to get property 'db' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 337
ERROR - 2021-09-15 10:01:50 --> Severity: error --> Exception: Call to a member function query() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 337
ERROR - 2021-09-15 10:02:51 --> Severity: Notice --> A non well formed numeric value encountered C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 373
ERROR - 2021-09-15 10:02:51 --> Query error: Table 'shop_uniquid' was not locked with LOCK TABLES - Invalid query: insert into shop_uniquid set up_id = '21091510025147', up_ip='::1'
ERROR - 2021-09-15 13:54:40 --> Severity: Compile Error --> Cannot redeclare file_put_contents() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\global_helper.php 743
ERROR - 2021-09-15 13:55:20 --> Severity: error --> Exception: Too few arguments to function get_birth_age(), 0 passed in C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php on line 14 and exactly 1 expected C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\global_helper.php 366
ERROR - 2021-09-15 13:57:40 --> Severity: Compile Error --> Cannot redeclare file_put_contents() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\global_helper.php 743
ERROR - 2021-09-15 14:00:44 --> Severity: Compile Error --> Cannot redeclare file_put_contents() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\global_helper.php 736
ERROR - 2021-09-15 14:01:07 --> Severity: Compile Error --> Cannot redeclare file_put_contents() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\global_helper.php 743
ERROR - 2021-09-15 14:24:37 --> Severity: Notice --> A non well formed numeric value encountered C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 382
ERROR - 2021-09-15 14:24:37 --> Query error: Table 'shop_uniquid' was not locked with LOCK TABLES - Invalid query: insert into shop_uniquid set up_id = '21091514243775', up_ip='::1'
ERROR - 2021-09-15 14:25:19 --> Severity: error --> Exception: Too few arguments to function is_null_time(), 0 passed in C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php on line 14 and exactly 1 expected C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 440
ERROR - 2021-09-15 14:26:32 --> Severity: Notice --> iconv(): Detected an illegal character in input string C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\custome_helper.php 510
ERROR - 2021-09-15 15:00:29 --> Severity: Notice --> Undefined variable: ci C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 175
ERROR - 2021-09-15 15:00:29 --> Severity: Notice --> Trying to get property 'db' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 175
ERROR - 2021-09-15 15:00:29 --> Severity: error --> Exception: Call to a member function query() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 175
ERROR - 2021-09-15 15:00:36 --> Severity: Notice --> Trying to get property 'catecode' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 180
ERROR - 2021-09-15 15:00:36 --> Severity: Notice --> Trying to get property 'catename' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 183
ERROR - 2021-09-15 15:01:06 --> Severity: Notice --> Trying to get property 'catecode' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 179
ERROR - 2021-09-15 15:01:06 --> Severity: Notice --> Trying to get property 'catename' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 182
ERROR - 2021-09-15 15:01:06 --> Severity: Notice --> Trying to get property 'catecode' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 179
ERROR - 2021-09-15 15:01:06 --> Severity: Notice --> Trying to get property 'catename' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 182
ERROR - 2021-09-15 15:02:03 --> Severity: Notice --> Undefined variable: ci C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 176
ERROR - 2021-09-15 15:02:03 --> Severity: Notice --> Trying to get property 'db' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 176
ERROR - 2021-09-15 15:02:03 --> Severity: error --> Exception: Call to a member function query() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 176
ERROR - 2021-09-15 15:02:13 --> Severity: Notice --> Trying to get property 'db' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 177
ERROR - 2021-09-15 15:02:13 --> Severity: error --> Exception: Call to a member function query() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\common_helper.php 177
ERROR - 2021-09-15 15:02:56 --> 404 Page Not Found: Shop/list.php
ERROR - 2021-09-15 15:03:00 --> 404 Page Not Found: Shop/list.php
