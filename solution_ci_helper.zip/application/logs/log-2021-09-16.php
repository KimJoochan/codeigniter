<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-16 10:11:38 --> Severity: error --> Exception: Call to undefined function get_move() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 14
ERROR - 2021-09-16 10:12:43 --> Severity: error --> Exception: Too few arguments to function CI_Loader::library(), 0 passed in C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php on line 13 and at least 1 expected C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\system\core\Loader.php 190
ERROR - 2021-09-16 10:13:10 --> Severity: Notice --> Undefined variable: thid C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\models\Query_model.php 5
ERROR - 2021-09-16 10:13:10 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\models\Query_model.php 5
ERROR - 2021-09-16 10:13:10 --> Severity: error --> Exception: Call to a member function database() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\models\Query_model.php 5
ERROR - 2021-09-16 10:16:34 --> Severity: Notice --> Undefined variable: db C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\config\config.php 527
ERROR - 2021-09-16 10:16:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 15
ERROR - 2021-09-16 10:20:00 --> Severity: Notice --> Undefined variable: db C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\config\common.php 3
ERROR - 2021-09-16 10:21:42 --> Severity: Warning --> mysqli_connect(): (HY000/1045): Access denied for user 'username'@'localhost' (using password: YES) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\config\common.php 8
ERROR - 2021-09-16 10:49:10 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\config\common.php 13
ERROR - 2021-09-16 10:56:47 --> Severity: Compile Error --> Can't use method return value in write context C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 18
ERROR - 2021-09-16 11:08:29 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:08:29 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:23 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:23 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:24 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:24 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:24 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:24 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:24 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:24 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:50 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:50 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:50 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:50 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:50 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:50 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:51 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:51 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:51 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:09:51 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:10:53 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:10:53 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:10:53 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:10:53 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:10:53 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:10:53 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:10 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:10 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:10 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:10 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:11 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:11 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:11 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:11 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:11 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:11 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:11 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:11 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:11 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:11 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 7
ERROR - 2021-09-16 11:11:50 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:11:50 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:22 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:22 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:23 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:23 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:23 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:23 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:23 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:23 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:23 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:23 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:24 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:24 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:24 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:13:24 --> Severity: error --> Exception: Call to a member function library() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:55 --> Severity: Notice --> Undefined variable: Ci C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:55 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:55 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:55 --> Severity: Notice --> Undefined variable: Ci C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:55 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:55 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: Notice --> Undefined variable: Ci C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: Notice --> Undefined variable: Ci C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: Notice --> Undefined variable: Ci C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: Notice --> Undefined variable: Ci C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:16:56 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:17:01 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:17:01 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:17:02 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:17:02 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:17:02 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:17:02 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:17:02 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:17:02 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 11:18:46 --> Severity: error --> Exception: syntax error, unexpected '$result' (T_VARIABLE) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\global_lib.php 384
ERROR - 2021-09-16 11:19:20 --> Severity: Compile Error --> Constant expression contains invalid operations C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\global_lib.php 5
ERROR - 2021-09-16 11:20:16 --> Severity: Notice --> Undefined index: cellphone C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 14
ERROR - 2021-09-16 11:34:10 --> Severity: Notice --> Undefined variable: super_hp C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 17
ERROR - 2021-09-16 11:34:33 --> Severity: Notice --> Undefined variable: super_hp C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 17
ERROR - 2021-09-16 11:34:49 --> Severity: Notice --> Undefined variable: super_hp C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 17
ERROR - 2021-09-16 12:36:43 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 12:36:43 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 8
ERROR - 2021-09-16 12:41:37 --> Severity: error --> Exception: Call to undefined function current_url() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\config\hooks.php 14
ERROR - 2021-09-16 12:41:43 --> Severity: error --> Exception: Call to undefined function base_url() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\config\hooks.php 14
ERROR - 2021-09-16 12:45:46 --> 404 Page Not Found: %E3%84%B4%E3%85%87%E3%84%B9/index
ERROR - 2021-09-16 12:46:32 --> 404 Page Not Found: %E3%84%B4%E3%85%87%E3%84%B9/index
ERROR - 2021-09-16 12:46:48 --> 404 Page Not Found: %E3%84%B4%E3%85%87%E3%84%B9/index
ERROR - 2021-09-16 12:46:54 --> 404 Page Not Found: %E3%84%B4%E3%85%87%E3%84%B9/index
ERROR - 2021-09-16 12:47:04 --> 404 Page Not Found: %E3%84%B4%E3%85%87%E3%84%B9/index
ERROR - 2021-09-16 12:47:38 --> Severity: error --> Exception: syntax error, unexpected ';' C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\config\hooks.php 18
ERROR - 2021-09-16 12:47:53 --> Severity: Notice --> Undefined offset: 3 C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\config\hooks.php 20
ERROR - 2021-09-16 12:47:53 --> 404 Page Not Found: %E3%84%B4%E3%85%87%E3%84%B9/index
ERROR - 2021-09-16 12:47:58 --> 404 Page Not Found: %E3%84%B4%E3%85%87%E3%84%B9/index
ERROR - 2021-09-16 12:48:05 --> 404 Page Not Found: Black/index
ERROR - 2021-09-16 12:48:16 --> 404 Page Not Found: Main/limit
ERROR - 2021-09-16 12:49:11 --> Severity: error --> Exception: syntax error, unexpected ';' C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\config\hooks.php 20
ERROR - 2021-09-16 13:10:30 --> Severity: error --> Exception: syntax error, unexpected ')' C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 94
ERROR - 2021-09-16 13:10:46 --> Severity: Notice --> Undefined index: ss_mb_id C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 83
ERROR - 2021-09-16 13:10:46 --> Severity: Notice --> Undefined index: 6e1280981e1dfd9169c5dea9c28ff2e3 C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\global_helper.php 1095
ERROR - 2021-09-16 13:11:06 --> Severity: Notice --> Undefined index: 6e1280981e1dfd9169c5dea9c28ff2e3 C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\global_helper.php 1095
ERROR - 2021-09-16 13:12:17 --> Severity: Notice --> Undefined index: 6e1280981e1dfd9169c5dea9c28ff2e3 C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\global_helper.php 1095
ERROR - 2021-09-16 13:12:17 --> Severity: Notice --> Undefined index: 6e1280981e1dfd9169c5dea9c28ff2e3 C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\helpers\global_helper.php 1095
ERROR - 2021-09-16 13:29:14 --> Severity: Notice --> Undefined property: global_complex_lib::$load C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\global_complex_lib.php 10
ERROR - 2021-09-16 13:29:14 --> Severity: error --> Exception: Call to a member function get_var() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\global_complex_lib.php 10
ERROR - 2021-09-16 15:24:16 --> Query error: No tables used - Invalid query: select * where id=TRIM('admin')
ERROR - 2021-09-16 15:27:34 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting function (T_FUNCTION) or const (T_CONST) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\complex_lib.php 13
ERROR - 2021-09-16 15:28:05 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting function (T_FUNCTION) or const (T_CONST) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\complex_lib.php 13
ERROR - 2021-09-16 15:28:24 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting function (T_FUNCTION) or const (T_CONST) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\complex_lib.php 13
ERROR - 2021-09-16 15:28:32 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting function (T_FUNCTION) or const (T_CONST) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\complex_lib.php 13
ERROR - 2021-09-16 15:28:40 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting function (T_FUNCTION) or const (T_CONST) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\complex_lib.php 13
ERROR - 2021-09-16 15:29:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''shop_member' limit 1' at line 1 - Invalid query:  select * from 'shop_member' limit 1 
ERROR - 2021-09-16 15:30:16 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\complex_lib.php 512
