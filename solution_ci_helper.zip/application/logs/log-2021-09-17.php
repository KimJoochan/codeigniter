<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-17 17:20:55 --> Severity: error --> Exception: syntax error, unexpected '"member"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 39
ERROR - 2021-09-17 17:21:41 --> Severity: error --> Exception: syntax error, unexpected '"member"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 40
ERROR - 2021-09-17 17:21:50 --> Severity: error --> Exception: syntax error, unexpected '"member"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 40
ERROR - 2021-09-17 17:22:05 --> Severity: error --> Exception: syntax error, unexpected '"member"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 40
ERROR - 2021-09-17 17:22:32 --> Severity: Notice --> Undefined index: id C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 184
ERROR - 2021-09-17 17:22:32 --> Severity: Notice --> Undefined variable: seller C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 196
ERROR - 2021-09-17 17:22:32 --> Severity: Notice --> Undefined variable: partner C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 196
ERROR - 2021-09-17 17:22:32 --> Severity: error --> Exception: Call to undefined function set_cookie() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 177
ERROR - 2021-09-17 17:22:44 --> Severity: Notice --> Undefined index: id C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 182
ERROR - 2021-09-17 17:22:44 --> Severity: Notice --> Undefined variable: seller C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 194
ERROR - 2021-09-17 17:22:44 --> Severity: Notice --> Undefined variable: partner C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 194
ERROR - 2021-09-17 17:22:44 --> Severity: error --> Exception: Call to undefined function set_cookie() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 175
ERROR - 2021-09-17 17:23:05 --> Severity: Notice --> Undefined variable: seller C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 194
ERROR - 2021-09-17 17:23:05 --> Severity: Notice --> Undefined variable: partner C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 194
ERROR - 2021-09-17 17:23:05 --> Severity: error --> Exception: Call to undefined function set_cookie() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 175
ERROR - 2021-09-17 17:23:30 --> Severity: Notice --> Undefined variable: partner C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 194
ERROR - 2021-09-17 17:23:30 --> Severity: error --> Exception: Call to undefined function set_cookie() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 175
ERROR - 2021-09-17 17:23:41 --> Severity: error --> Exception: syntax error, unexpected '''' (T_CONSTANT_ENCAPSED_STRING) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 181
ERROR - 2021-09-17 17:23:51 --> Severity: error --> Exception: Call to undefined function set_cookie() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Demo.php 175
ERROR - 2021-09-17 17:25:26 --> Unable to load the requested class: Global_complex_lib
ERROR - 2021-09-17 17:26:25 --> Severity: Notice --> Undefined property: Main::$conifg C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 15
ERROR - 2021-09-17 17:26:25 --> Severity: error --> Exception: Call to a member function item() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 15
ERROR - 2021-09-17 17:26:39 --> Severity: Notice --> Undefined property: Main::$conifg C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 15
ERROR - 2021-09-17 17:26:39 --> Severity: error --> Exception: Call to a member function load() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 15
