<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-23 11:21:37 --> Severity: error --> Exception: Class 'html_process' not found C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Common.php 41
ERROR - 2021-09-23 12:30:49 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Db_table_optimize.php 2
ERROR - 2021-09-23 12:30:59 --> Non-existent class: Gvcomplex_lib
ERROR - 2021-09-23 12:32:54 --> Non-existent class: Gvcomplex_lib
ERROR - 2021-09-23 12:33:18 --> Severity: error --> Exception: syntax error, unexpected '$result' (T_VARIABLE) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\funcomplex_lib.php 1554
ERROR - 2021-09-23 12:34:01 --> Severity: error --> Exception: syntax error, unexpected '$sql2' (T_VARIABLE) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\funcomplex_lib.php 1931
ERROR - 2021-09-23 12:34:22 --> Severity: error --> Exception: syntax error, unexpected '$res' (T_VARIABLE) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\funcomplex_lib.php 1998
ERROR - 2021-09-23 12:34:43 --> Severity: error --> Exception: syntax error, unexpected '$row' (T_VARIABLE) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\funcomplex_lib.php 2725
ERROR - 2021-09-23 12:35:08 --> Severity: error --> Exception: syntax error, unexpected '$str' (T_VARIABLE) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\funcomplex_lib.php 3251
ERROR - 2021-09-23 12:35:36 --> Severity: error --> Exception: syntax error, unexpected '$gw_array_status' (T_VARIABLE) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\funcomplex_lib.php 3396
ERROR - 2021-09-23 12:35:53 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\funcomplex_lib.php 4763
ERROR - 2021-09-23 12:36:27 --> Severity: error --> Exception: syntax error, unexpected '$str' (T_VARIABLE) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\funcomplex_lib.php 5046
ERROR - 2021-09-23 12:36:49 --> Severity: error --> Exception: syntax error, unexpected '$pt_id' (T_VARIABLE) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\funcomplex_lib.php 5220
ERROR - 2021-09-23 12:37:06 --> Non-existent class: Funcomplex_lib
ERROR - 2021-09-23 12:37:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Upload_files C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\system\core\Loader.php 348
ERROR - 2021-09-23 12:38:21 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; upload_files has a deprecated constructor C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\upload_files.php 3
ERROR - 2021-09-23 12:38:21 --> Severity: error --> Exception: Too few arguments to function upload_files::upload_files(), 0 passed in C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\system\core\Loader.php on line 1285 and exactly 1 expected C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\upload_files.php 7
ERROR - 2021-09-23 12:40:02 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; upload_files has a deprecated constructor C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\upload_files.php 3
ERROR - 2021-09-23 12:40:02 --> Severity: error --> Exception: Too few arguments to function upload_files::upload_files(), 0 passed in C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\system\core\Loader.php on line 1285 and exactly 1 expected C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\upload_files.php 7
ERROR - 2021-09-23 12:52:14 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 9
ERROR - 2021-09-23 12:52:14 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 9
ERROR - 2021-09-23 12:52:15 --> Severity: Notice --> Trying to get property 'load' of non-object C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 9
ERROR - 2021-09-23 12:52:15 --> Severity: error --> Exception: Call to a member function model() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 9
ERROR - 2021-09-23 13:04:40 --> Severity: Notice --> Undefined property: Main::$gvcomplex_lib C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 31
ERROR - 2021-09-23 13:04:40 --> Severity: error --> Exception: Call to a member function get_basedomain() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 31
ERROR - 2021-09-23 13:07:26 --> Severity: Notice --> Undefined property: Main::$gvcomplex_lib C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 31
ERROR - 2021-09-23 13:07:26 --> Severity: error --> Exception: Call to a member function get_basedomain() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 31
ERROR - 2021-09-23 13:07:38 --> Severity: Notice --> Undefined property: Main::$gvcomplex_lib C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 32
ERROR - 2021-09-23 13:07:38 --> Severity: error --> Exception: Call to a member function get_basedomain() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 32
ERROR - 2021-09-23 13:08:25 --> Severity: Notice --> Undefined property: Main::$gvcomplex_lib C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 31
ERROR - 2021-09-23 13:08:25 --> Severity: error --> Exception: Call to a member function get_basedomain() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 31
ERROR - 2021-09-23 13:08:42 --> Severity: Notice --> Undefined property: Main::$gvcomplex_lib C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 32
ERROR - 2021-09-23 13:08:42 --> Severity: error --> Exception: Call to a member function get_basedomain() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 32
ERROR - 2021-09-23 13:08:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php:28) C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\system\core\Common.php 570
ERROR - 2021-09-23 13:09:25 --> Severity: Notice --> Undefined variable: host C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 49
ERROR - 2021-09-23 13:10:18 --> Severity: Notice --> Undefined property: Main::$gvcomplex_lib C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 31
ERROR - 2021-09-23 13:10:18 --> Severity: error --> Exception: Call to a member function get_basedomain() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 31
ERROR - 2021-09-23 13:11:18 --> Severity: Notice --> Undefined property: Main::$funcomplex_lib C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 54
ERROR - 2021-09-23 13:11:18 --> Severity: error --> Exception: Call to a member function is_partner() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 54
ERROR - 2021-09-23 13:16:03 --> Severity: Notice --> Undefined variable: pt_id C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 56
ERROR - 2021-09-23 13:19:46 --> Severity: Notice --> Undefined property: Main::$funcomplex_lib C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 54
ERROR - 2021-09-23 13:19:46 --> Severity: error --> Exception: Call to a member function is_partner() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 54
ERROR - 2021-09-23 13:38:56 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 148
ERROR - 2021-09-23 13:39:20 --> Unable to load the requested class: Security
ERROR - 2021-09-23 13:40:17 --> Severity: Notice --> Undefined variable: OM_TIME_YMDHIS C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 19
ERROR - 2021-09-23 13:40:17 --> Severity: Notice --> Undefined variable: OM_TIME_YMDHIS C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 20
ERROR - 2021-09-23 13:40:17 --> Severity: Notice --> Undefined variable: pt_id C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 106
ERROR - 2021-09-23 13:40:17 --> Severity: Notice --> Undefined variable: pt_id C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 114
ERROR - 2021-09-23 13:40:17 --> Query error: Incorrect DATE value: '' - Invalid query:  select vs_count as cnt 
                        from shop_visit_sum 
                        where vs_date = '' 
                            and mb_id = '' 
ERROR - 2021-09-23 13:43:58 --> Severity: Notice --> Undefined variable: is_member C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 85
ERROR - 2021-09-23 14:09:12 --> Severity: Notice --> Undefined variable: OM_TIME_YMDHIS C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\delete_funcomplex_lib.php 19
ERROR - 2021-09-23 14:09:12 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\config\shop_extend.php 67
ERROR - 2021-09-23 14:09:22 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\config\shop_extend.php 67
ERROR - 2021-09-23 14:13:55 --> Severity: Notice --> Undefined variable: OM_TIME_YMDHIS C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\libraries\funcomplex_lib.php 19
ERROR - 2021-09-23 14:14:40 --> Severity: Notice --> Undefined variable: pt_id C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 186
ERROR - 2021-09-23 14:14:40 --> Severity: Notice --> Undefined index: shop_private C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 146
ERROR - 2021-09-23 14:14:40 --> Severity: Notice --> Undefined index: shop_policy C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 147
ERROR - 2021-09-23 14:14:40 --> Severity: error --> Exception: Call to undefined method funcomplex_lib::start() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 13
ERROR - 2021-09-23 14:15:51 --> Severity: Notice --> Undefined index: shop_private C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 146
ERROR - 2021-09-23 14:15:51 --> Severity: Notice --> Undefined index: shop_policy C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 147
ERROR - 2021-09-23 14:15:51 --> Severity: error --> Exception: Call to undefined method funcomplex_lib::start() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 13
ERROR - 2021-09-23 14:16:15 --> Severity: error --> Exception: Call to undefined method funcomplex_lib::start() C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\controllers\Main.php 13
ERROR - 2021-09-23 14:22:27 --> Severity: Notice --> Undefined property: Main::$funcomplex_lib C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 61
ERROR - 2021-09-23 14:22:27 --> Severity: error --> Exception: Call to a member function is_partner() on null C:\Bitnami\wampstack-7.2.30-0\apache2\htdocs\solution_ci_helper\application\hooks\Partner_config.php 61
