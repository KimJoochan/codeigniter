<?php 

class Query_model extends CI_Model {
    function __construct() { 
        $this->load->database();
        parent::__construct(); 
    }
    function returnOneArr($sql,$data=null){
        return $this->db->query($sql,$data)->row_array();
    }
    function returnArr($sql,$data=null){
        return $this->db->query($sql,$data)->result_array();
    }
    function returnQueryObj($sql,$data=null){
        return $this->db->query($sql,$data);
    }
    function returnNull($sql,$data=null){
        $this->db->query($sql,$data);
    }
    function returnInsertId($sql,$data=null){
        $this->db->query($sql,$data);
        return $this->db->insert_id();
    }
    function insertObj($table,$data){
        $this->db->insert($table,$data);
    }
    function updateObj($table,$data,$where){
        $this->db->update($table,$date,$where);
    }
}
?>