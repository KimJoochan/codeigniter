modify=20171111034405;perm=flcdmpe;type=cdir;unique=904U9E1096;UNIX.group=658;UNIX.mode=0775;UNIX.owner=662; .
modify=20171111034405;perm=flcdmpe;type=pdir;unique=904U9E0BCA;UNIX.group=658;UNIX.mode=0775;UNIX.owner=662; ..
modify=20171111034405;perm=flcdmpe;type=dir;unique=904U9E1097;UNIX.group=658;UNIX.mode=0775;UNIX.owner=662; uk
